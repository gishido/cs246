package shumway;

public class Main {

    public static void main(String[] args) {
	      TweetLoader newLoad = new TweetLoader();

	      newLoad.retrieveTweetsWithHashTag("#byui");
    }
}
