package prove02;

/**
 * Created by thesh on 4/28/2017.
 */
public interface Spawner {

  // to be used to spawn baby wolves!
  public Creature spawnNewCreature();
}
