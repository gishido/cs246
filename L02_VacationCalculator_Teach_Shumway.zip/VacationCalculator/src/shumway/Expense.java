package shumway;

/**
 * Created by thesh on 4/25/2017.
 */
public interface Expense {
  float getCost();
}
