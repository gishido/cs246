package shumway;

/**
 * Created by thesh on 4/25/2017.
 */
public enum Destination {
  Mexico, Europe, Japan
}
