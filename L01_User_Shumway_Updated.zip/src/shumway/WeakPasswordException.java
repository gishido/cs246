package shumway;

/**
 * Created by thesh on 4/21/2017.
 */
public class WeakPasswordException extends Exception {

  public WeakPasswordException(String theException) {
    super(theException);
  }

}
